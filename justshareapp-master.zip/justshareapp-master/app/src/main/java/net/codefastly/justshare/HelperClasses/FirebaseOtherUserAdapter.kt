package net.codefastly.justshare.HelperClasses

import android.content.Context
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.recyclerview.widget.RecyclerView
import com.squareup.picasso.Picasso
import net.codefastly.justshare.Models.FirebasePublication
import net.codefastly.justshare.R
import net.codefastly.justshare.Utils._chooseIconWithLink

class FirebaseOtherUserAdapter(private val context: Context): RecyclerView.Adapter<FirebaseOtherUserAdapter.FirebaseUserViewHolder>() {

    private var dataList = mutableListOf<FirebasePublication>()

    fun setListData(data: MutableList<FirebasePublication>){
        dataList = data
    }

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ):  FirebaseUserViewHolder {
        val view = LayoutInflater.from(context).inflate(R.layout.rv_item_user, parent, false)
        return FirebaseUserViewHolder(view)
    }

    override fun getItemCount(): Int {
        return if (dataList.size > 0){
            dataList.size
        } else {
            0
        }
    }

    override fun onBindViewHolder(
        holder: FirebaseUserViewHolder,
        position: Int
    ) {
        val publication = dataList[position]
        holder.render(publication)
    }

    inner class FirebaseUserViewHolder( itemView: View): RecyclerView.ViewHolder( itemView ){
        fun render( publication: FirebasePublication) {

            if(publication.imageUrl.isEmpty()){
                Picasso.get().load(context.getString(R.string.publication_image_link)).placeholder(R.drawable.ic_launcher_background).into(itemView.findViewById<ImageView>(R.id.imgUser))
            }else{
                Picasso.get().load(publication.imageUrl).placeholder(R.drawable.ic_launcher_background).into(itemView.findViewById<ImageView>(R.id.imgUser))
            }

            // Change LinkIcon

            itemView.findViewById<ImageView>(R.id.imgLinkType).setBackgroundResource( _chooseIconWithLink( ( publication.url ) ) )


        }
    }

}