package net.codefastly.justshare.HelperClasses

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import net.codefastly.justshare.Models.Comment
import net.codefastly.justshare.R
import com.squareup.picasso.Picasso

class FirebaseCommentsAdapter( private val context: Context ): RecyclerView.Adapter<FirebaseCommentsAdapter.FirebaseCommentsViewHolder>() {

    private var dataList = mutableListOf<Comment>()

    fun setListData( data: MutableList<Comment> ){
        dataList = data
    }

    override fun onCreateViewHolder( parent: ViewGroup, viewType: Int ): FirebaseCommentsAdapter.FirebaseCommentsViewHolder {
        val view = LayoutInflater.from( context ).inflate( R.layout.rv_item_comments, parent, false )
        return FirebaseCommentsViewHolder( view )
    }

    override fun onBindViewHolder(
        holder: FirebaseCommentsAdapter.FirebaseCommentsViewHolder,
        position: Int
    ) {
        val commentItem = dataList[position]
        holder.render(commentItem)
    }

    override fun getItemCount(): Int {
        return if(dataList.size > 0){
            dataList.size
        }else{
            0
        }
    }

    inner class FirebaseCommentsViewHolder( itemView: View): RecyclerView.ViewHolder( itemView ){

        fun render( commentItem: Comment ){

            Picasso.get().load( commentItem.userImage ).into(itemView.findViewById<ImageView>(R.id.imgOwner))
            itemView.findViewById<TextView>(R.id.tvOwner).text = commentItem.username
            itemView.findViewById<TextView>(R.id.tvMessage).text = commentItem.text


        }

    }


}