package net.codefastly.justshare.User

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import net.codefastly.justshare.R

class UserDashboard : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_user_dashboard)

        title = "Dashboard"

    }
}