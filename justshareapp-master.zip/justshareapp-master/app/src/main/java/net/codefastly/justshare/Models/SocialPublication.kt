package net.codefastly.justshare.Models

import java.io.Serializable

class SocialPublication(
    val publication: FirebasePublication,
    val user: FirebaseUser
    ): Serializable
    {
    }