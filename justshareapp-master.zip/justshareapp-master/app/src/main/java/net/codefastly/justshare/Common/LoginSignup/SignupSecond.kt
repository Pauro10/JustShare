package net.codefastly.justshare.Common.LoginSignup

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import androidx.databinding.DataBindingUtil
import net.codefastly.justshare.R
import net.codefastly.justshare.Utils.snack
import net.codefastly.justshare.databinding.ActivitySignupSecondBinding
import java.util.*


class SignupSecond : AppCompatActivity() {

    private lateinit var binding: ActivitySignupSecondBinding

    // User variables
    private lateinit var tBirthday: String
    private lateinit var tGender: String
    private lateinit var tFullName: String
    private lateinit var tUserName: String
    private lateinit var tEmail: String
    private lateinit var tPassword: String



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        this.binding    = DataBindingUtil.setContentView(this, R.layout.activity_signup_second)
        fullScreenMode()

        // USER DATA
        this.tFullName  = intent.getStringExtra("EXTRA_SESSION_FULLNAME").toString()
        this.tUserName  = intent.getStringExtra("EXTRA_SESSION_USERNAME").toString()
        this.tEmail     = intent.getStringExtra("EXTRA_SESSION_EMAIL").toString()
        this.tPassword  = intent.getStringExtra("EXTRA_SESSION_PASSWORD").toString()

        // LISTENERS

        // Next Signup Screen
        this.binding.btnContinue.setOnClickListener {

            it.snack("$tFullName($tUserName),email:$tEmail --> $tPassword")

            // Validate DatePicker
            val selectedDay: Int = this.binding.dpNacimiento.dayOfMonth
            val selectedMonth: Int = this.binding.dpNacimiento.month + 1
            val selectedYear: Int = this.binding.dpNacimiento.year
            this.tBirthday = "$selectedDay/$selectedMonth/$selectedYear"

            // Validate RadioButtons
            when {
                this.binding.rbFemale.isChecked -> {
                    this.tGender = "F"
                }
                this.binding.rbMale.isChecked -> {
                    this.tGender = "M"
                }
                else -> {
                    this.tGender = "O"
                }
            }

            //it.snack("Nacimiento: $tBirthday,Genero: $tGender")
            changeScreen(it, 2)
        }

        // Login Screen
        this.binding.btnLogin.setOnClickListener {
            changeScreen(it, 1)
        }

        // Back Screen
        this.binding.btnSignUpBack.setOnClickListener {
            changeScreen(it, 0)
        }


    }

    private fun changeScreen(view: View, option: Int ){
        var intent = Intent()

        when(option){
            0 -> {
                // Back Screen
                intent = Intent(applicationContext, RetailerStartUpScreen::class.java)
            }
            1 -> {
                // LogIn Screen
                intent = Intent(applicationContext, Login::class.java)
            }
            2 -> {
                // SignUp Screen
                intent = Intent(applicationContext, SignupThird::class.java).apply {
                    this.putExtra("EXTRA_SESSION_USERNAME", tUserName )
                    this.putExtra("EXTRA_SESSION_EMAIL", tEmail )
                    this.putExtra("EXTRA_SESSION_PASSWORD", tPassword )
                    this.putExtra("EXTRA_SESSION_FULLNAME", tFullName )
                    this.putExtra("EXTRA_SESSION_GENDER", tGender )
                    this.putExtra("EXTRA_SESSION_BIRTHDAY", tBirthday )
                }
            }
        }

        startActivity(intent)
        if(option == 0){
            overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right)
        }else{
            overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left)
        }
        finish()
    }

    private fun  fullScreenMode(){
        // Hide actionBar and fullScreen mode
        supportActionBar?.hide()
        window.setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN)
    }

}