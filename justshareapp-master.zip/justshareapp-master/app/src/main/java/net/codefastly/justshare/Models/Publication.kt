package net.codefastly.justshare.Models

import java.time.LocalDateTime

data class Publication(
        val owner: String,
        val description: String,
        val url: String,
        val categories: String,
        val imageUrl: String,
        val click: Int = 0,
        val creationDate: LocalDateTime = LocalDateTime.now()
    )   {
            // Empty body
        }