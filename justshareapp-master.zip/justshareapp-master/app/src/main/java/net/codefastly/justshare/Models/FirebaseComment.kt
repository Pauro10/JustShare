package net.codefastly.justshare.Models

class FirebaseComment
    (
        val user_id: String,
        val publication_id: String,
        val text: String
    )
{
}