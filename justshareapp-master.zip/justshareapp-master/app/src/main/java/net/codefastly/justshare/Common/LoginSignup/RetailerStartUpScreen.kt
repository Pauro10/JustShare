package net.codefastly.justshare.Common.LoginSignup

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import androidx.databinding.DataBindingUtil
import net.codefastly.justshare.R
import net.codefastly.justshare.Utils.snack
import net.codefastly.justshare.databinding.ActivityRetailerStartUpScreenBinding

class RetailerStartUpScreen : AppCompatActivity() {

    private lateinit var binding: ActivityRetailerStartUpScreenBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        fullScreenMode()

        this.binding = DataBindingUtil.setContentView(this, R.layout.activity_retailer_start_up_screen )

        this.binding.btnLogin.setOnClickListener {
            // Call to Sin In Screen
            changeScreen( it, 1 )
        }

        this.binding.btnSignup.setOnClickListener {
            // Call to Sign Up Screen
            changeScreen( it, 2 )
        }

        this.binding.btnHowWeWork.setOnClickListener {
            it.snack(getString(R.string.retailer_implement))
        }




    }


    private fun  fullScreenMode(){
        // Hide actionBar and fullScreen mode
        supportActionBar?.hide()
        window.setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN)
    }


    private fun changeScreen( view: View, option: Int ){
        var intent = Intent()

        when(option){
            1 -> {
                // LogIn Screen
                intent = Intent(applicationContext, Login::class.java)
            }
            2 -> {
                // SignUp Screen
                intent = Intent(applicationContext, Signup::class.java)
            }
        }

        startActivity(intent)
        overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left)
        finish()
    }

}