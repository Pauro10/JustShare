package net.codefastly.justshare.Common.DashboardViews

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.StaggeredGridLayoutManager
import net.codefastly.justshare.Common.Controllers.TrendsFragmentVM
import net.codefastly.justshare.HelperClasses.FirebaseTrendsAdapter
import net.codefastly.justshare.R
import net.codefastly.justshare.databinding.FragmentTrendsBinding

class TrendsFragment : Fragment() {

    private lateinit var binding : FragmentTrendsBinding

    // Inicializamos viewModel cuando lo necesitamos
    private val viewModel by lazy { ViewModelProvider(this).get(TrendsFragmentVM::class.java) }

    private lateinit var trendsAdapter: FirebaseTrendsAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        this.binding = DataBindingUtil.inflate(inflater, R.layout.fragment_trends, container, false)

        // Initialize Trends RecyclerView
        this.initTrendsRecycler()

        return this.binding.root
    }

    private fun initTrendsRecycler(){
        this.binding.rvTrends.layoutManager = StaggeredGridLayoutManager(2, StaggeredGridLayoutManager.VERTICAL)
        this.trendsAdapter = FirebaseTrendsAdapter( requireContext() )
        this.binding.rvTrends.adapter = this.trendsAdapter

        this.observePublicationData()
    }

    private fun observePublicationData(){
        this.viewModel.fetchPublicationData().observe( viewLifecycleOwner, Observer { obsPublication ->
            this.trendsAdapter.setListData(obsPublication)
            this.trendsAdapter.notifyDataSetChanged()
        })
    }


}