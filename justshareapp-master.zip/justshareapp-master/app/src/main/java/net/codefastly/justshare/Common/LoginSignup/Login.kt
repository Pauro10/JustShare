package net.codefastly.justshare.Common.LoginSignup

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import androidx.appcompat.app.AlertDialog
import androidx.databinding.DataBindingUtil
import net.codefastly.justshare.Common.DashboardActivity
import net.codefastly.justshare.R
import net.codefastly.justshare.Utils.snack
import net.codefastly.justshare.databinding.ActivityLoginBinding
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.ApiException
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.GoogleAuthProvider

class Login : AppCompatActivity() {

    private lateinit var binding: ActivityLoginBinding
    private lateinit var auth: FirebaseAuth
    private var remember: Boolean = false
    private val GOOGLE_SIGN_IN = 100

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        this.binding = DataBindingUtil.setContentView(this, R.layout.activity_login)

        fullScreenMode()

        // Initialize Firebase Auth
        auth = FirebaseAuth.getInstance()

        // Show snack if signup is succesfull
        val view = this.binding.root
        if (intent.getBooleanExtra("EXTRA_SHOW_SNACK", false)){
            view.snack(getString(R.string.login_rgexit))
        }

        // LISTENERS

        // Back Screen
        this.binding.btnLoginpBack.setOnClickListener {
            changeScreen(it, 0)
        }

        // Validate Account
        this.binding.btnLogin.setOnClickListener {
            // Validamos campos antes de hacer la petición a la base de datos

            if( !validateFields(it) ){
                return@setOnClickListener
            }

            // Enviamos petición a FirebaseAuth para identificar usuario
            this.logIn( it,
                this.binding.tfEmail.text.toString().trim(),
                this.binding.tfPass.text.toString().trim() )

        }

        //Login Google
        this.binding.btnGoogle.setOnClickListener {
            //Configuracion
            val googleConf = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestIdToken(getString(R.string.default_web_client_id))
                .requestEmail()
                .build()

            val googleClient = GoogleSignIn.getClient(this, googleConf)
            googleClient.signOut()

            startActivityForResult(googleClient.signInIntent, GOOGLE_SIGN_IN)
        }


        // Signup Screen
        this.binding.btnSignup.setOnClickListener {
            changeScreen(it, 1)
        }

        // Forget Password Screen
        this.binding.btnForgetPass.setOnClickListener {
            it.snack(getString(R.string.login_futimp))
        }

        // Remember my account option
        this.binding.cbRemember.setOnClickListener {
            this.remember = !this.remember
            //it.snack("Recordar: ${this.remember}")
        }

    }

    override fun onStart() {
        super.onStart()

        // Comprobaremos si el usuario ya ha accedido
        /*
        val currentUser = auth.currentUser
        updateUI(currentUser)
         */
    }

    private fun changeScreen(view: View, option: Int ){
        var intent = Intent()

        when(option){
            0 -> {
                // Back Screen
                intent = Intent(applicationContext, RetailerStartUpScreen::class.java)


            }
            1 -> {
                // SignUp Screen
                intent = Intent(applicationContext, Signup::class.java)
            }
        }

        startActivity(intent)
        if(option == 0){
            overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right)
        }else{
            overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left)
        }
        finish()
    }

    private fun validateFields(view: View): Boolean {

        val EMAIL_REGEX = "^[A-Za-z](.*)([@]{1})(.{1,})(\\.)(.{1,})"

        // Validate password
        return if( this.binding.tfPass.text.toString() == "" || this.binding.tfPass.text.toString().length < 6 ) {
            view.snack(getString(R.string.login_charpass))
            false
        } else if( this.binding.tfEmail.text.toString() == "" || !this.binding.tfEmail.text.toString().contains(regex = EMAIL_REGEX.toRegex())) {
            view.snack(getString(R.string.login_emailvalid))
            false
        } else{
            true
        }

    }

    private fun logIn( view: View, email: String, password: String ){
        this.auth.signInWithEmailAndPassword(email, password)
            .addOnCompleteListener(this) { task ->
                if( task.isSuccessful ){

                    view.snack(getString(R.string.login_exit))
                    val prefs = getSharedPreferences(getString(R.string.prefs_file), Context.MODE_PRIVATE).edit()
                    prefs.putString("currentUid", auth.currentUser?.uid!!)
                    prefs.putBoolean("rememberOption", remember)
                    prefs.apply()
                    intent = Intent(applicationContext, DashboardActivity::class.java)
                    startActivity(intent)
                }else{
                    view.snack(getString(R.string.login_coinc))
                }
            }
    }


    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == GOOGLE_SIGN_IN) {

            val task = GoogleSignIn.getSignedInAccountFromIntent(data)

            try {

                val account = task.getResult(ApiException::class.java)

                if (account != null) {

                    val credential = GoogleAuthProvider.getCredential(account.idToken, null)

                    FirebaseAuth.getInstance().signInWithCredential(credential)
                        .addOnCompleteListener {

                            if (it.isSuccessful) {
                                val prefs = getSharedPreferences(getString(R.string.prefs_file), Context.MODE_PRIVATE).edit()
                                //prefs.putString("UID", auth.currentUser?.uid)
                                prefs.putBoolean("rememberOption", true)
                                prefs.apply()
                                intent = Intent(applicationContext, DashboardActivity::class.java)
                                startActivity(intent)
                            } else {
                                showAlert()
                            }
                        }
                }
            } catch (e: ApiException) {
                showAlert()
            }


        }
    }

    private fun showAlert() {

        val builder = AlertDialog.Builder(this)
        builder.setTitle(getString(R.string.login_error))
        builder.setMessage(getString(R.string.login_error2))
        builder.setPositiveButton(getString(R.string.login_error3), null)
        val dialog: AlertDialog = builder.create()
        dialog.show()
    }

    private fun  fullScreenMode(){
        // Hide actionBar and fullScreen mode
        supportActionBar?.hide()
        window.setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN)
    }


}