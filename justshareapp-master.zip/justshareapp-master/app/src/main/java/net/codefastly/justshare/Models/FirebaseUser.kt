package net.codefastly.justshare.Models

import java.time.LocalDateTime

class FirebaseUser (
    val fullName: String,
    val username: String,
    val password: String,
    val gender: String,
    val birthday: String,
    val phoneNumber: String,
    val countryCode: String,
    val profileImage: String,
    val registrationDate: LocalDateTime = LocalDateTime.now(),
    val id: String = ""
)