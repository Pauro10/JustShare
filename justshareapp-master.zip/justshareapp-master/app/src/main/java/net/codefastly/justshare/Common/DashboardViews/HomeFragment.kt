package net.codefastly.justshare.Common.DashboardViews

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import net.codefastly.justshare.Common.Controllers.HomeFragmentVM
import net.codefastly.justshare.HelperClasses.FirebaseFollowingAdapter
import net.codefastly.justshare.HelperClasses.FirebaseTrendsAdapter
import net.codefastly.justshare.R
import net.codefastly.justshare.databinding.FragmentHomeBinding


class HomeFragment : Fragment() {

    private lateinit var binding: FragmentHomeBinding

    // Inicializamos viewModel cuando lo necesitamos
    private val viewModel by lazy { ViewModelProvider(this).get(HomeFragmentVM::class.java) }

    // RECYCLER VIEW FOLLOWING
    private lateinit var followingAdapter: FirebaseFollowingAdapter
    private lateinit var trendsAdapter: FirebaseTrendsAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        this.binding = DataBindingUtil.inflate(inflater, R.layout.fragment_home, container, false)

        // Initializamos los recyclerViews
        this.initTrendsRecycler()
        this.initFollowingRecycler()
        // Observamos la data
        this.observeData()


        // Ponemo el foco en el buscador para solucionar bug....:')
        //this.binding.tfBuscador.requestFocus()

        return this.binding.root
    }

    // Initialize first RecyclerView
    private fun initFollowingRecycler(){
        this.binding.rvFollowing.layoutManager = LinearLayoutManager( requireContext(), LinearLayoutManager.HORIZONTAL, false )
        this.followingAdapter = FirebaseFollowingAdapter( requireContext() )
        this.binding.rvFollowing.adapter = this.followingAdapter
    }

    private fun initTrendsRecycler(){
        this.binding.rvTrends.layoutManager = LinearLayoutManager( requireContext(), LinearLayoutManager.HORIZONTAL, false )
        this.trendsAdapter = FirebaseTrendsAdapter( requireContext() )
        this.binding.rvTrends.adapter = this.trendsAdapter
    }

    private fun observeData(){
        this.binding.shimmerViewRvFollowing.startShimmer()
        this.viewModel.fetchFollowingItems().observe( viewLifecycleOwner, Observer { followingItem ->
            this.followingAdapter.setListData( followingItem )
            this.followingAdapter.notifyDataSetChanged()

            this.binding.shimmerViewRvTrends.startShimmer()
            this.viewModel.fetchPublicationData().observe( viewLifecycleOwner, Observer { obsPublication ->

                // Ocultamos Shimmer
                this.binding.shimmerViewRvFollowing.stopShimmer()
                this.binding.shimmerViewRvTrends.stopShimmer()
                this.binding.shimmerViewRvFollowing.visibility = View.GONE
                this.binding.shimmerViewRvTrends.visibility = View.GONE

                this.trendsAdapter.setListData(obsPublication)
                this.trendsAdapter.notifyDataSetChanged()
            })
        })
    }


}