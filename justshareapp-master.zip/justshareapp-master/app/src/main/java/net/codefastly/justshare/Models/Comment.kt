package net.codefastly.justshare.Models

class Comment
    (
    val user_id: String,
    var userImage: String,
    val publication_id: String,
    val text: String,
    var username: String,
    val id : String = ""
    )
{
}