package net.codefastly.justshare.Utils

import android.annotation.SuppressLint
import net.codefastly.justshare.R


/*------------ ICONS -------------*/

private val fab_instagram   = R.drawable.fab_instagram
private val fab_facebook    = R.drawable.fab_facebook
private val fab_music       = R.drawable.fab_music
private val fab_podcast     = R.drawable.fab_podcast
private val fab_snapchat    = R.drawable.fab_snapchat
private val fab_soundcloud  = R.drawable.fab_soundcloud
private val fab_spotify     = R.drawable.fab_spotify
private val fab_tiktok      = R.drawable.fab_tiktok
private val fab_twitch      = R.drawable.fab_twitch
private val fab_twitter     = R.drawable.fab_twitter
private val fab_youtube     = R.drawable.fab_youtube
private val fab_reddit      = R.drawable.fab_reddit
private val fab_globe       = R.drawable.fab_globe

/*------------ REGEX -------------*/


/*
private val youtubeReg      = Regex("""/youtube.{1}([A-z]{2,3})\D/gi""")
private val instagramReg    = Regex("""/instagram.{1}([A-z]{2,3})\D/gi""")
private val facebookReg     = Regex("""/facebook.{1}([A-z]{2,3})\D/gi""")
private val spotifyReg      = Regex("""/spotify.{1}([A-z]{2,3})\D/gi""")
private val twitchReg       = Regex("""/twitch.{1}([A-z]{2,3})\D/gi""")
private val twitterReg      = Regex("""/twitter.{1}([A-z]{2,3})\D/gi""")
private val redditReg       = Regex("""/reddit.{1}([A-z]{2,3})\D/gi""")
private val snapchatReg     = Regex("""/snapchat.{1}([A-z]{2,3})\D/gi""")
private val soundcloudReg   = Regex("""/soundcloud.{1}([A-z]{2,3})\D/gi""")
private val tiktokReg       = Regex("""/tiktok.{1}([A-z]{2,3})\D/gi"""")
private val podcastReg      = Regex("""/(stereo|overcast|podimo|spreaker|castbox).{1}([A-z]{2,3})\D/i""")
private val musicReg        = Regex("""/music.{1}([A-z]{2,3})\D/i""")
 */


private val youtubeReg      = Regex("youtu.be")
private val instagramReg    = Regex("instagram")
private val facebookReg     = Regex("facebook")
private val spotifyReg      = Regex("spotify")
private val twitchReg       = Regex("twitch")
private val twitterReg      = Regex("twitter")
private val redditReg       = Regex("reddit")
private val snapchatReg     = Regex("snapchat")
private val soundcloudReg   = Regex("soundcloud")
private val tiktokReg       = Regex("tiktok")
private val podcastReg      = Regex("(stereo|overcast|podimo|spreaker|castbox)")
private val musicReg        = Regex("music")




/*------------ MÉTODOS -------------*/


fun _chooseIconWithLink(link: String ): Int {

    return when {
        link.contains( youtubeReg )      -> fab_youtube
        link.contains( instagramReg )    -> fab_instagram
        link.contains( facebookReg )     -> fab_facebook
        link.contains( spotifyReg )      -> fab_spotify
        link.contains( twitchReg)        -> fab_twitch
        link.contains( twitterReg )      -> fab_twitter
        link.contains( redditReg )       -> fab_reddit
        link.contains( podcastReg )      -> fab_podcast
        link.contains( snapchatReg )     -> fab_snapchat
        link.contains( tiktokReg )       -> fab_tiktok
        link.contains( soundcloudReg )   -> fab_soundcloud
        link.contains(musicReg )         -> fab_music
        else                             -> fab_globe
    }

}

fun _splitLinks( link: String ): String {
    return when {
        link.contains( youtubeReg )      -> "https://www.youtube.com/..."
        link.contains( instagramReg )    -> "https://www.instagram.com/..."
        link.contains( facebookReg )     -> "https://www.facebook.com/..."
        link.contains( spotifyReg )      -> "https://www.spotify.com/..."
        link.contains( twitchReg)        -> "https://www.twitch.com/..."
        link.contains( twitterReg )      -> "https://www.twitter.com/..."
        link.contains( redditReg )       -> "https://www.reddit.com/..."
        link.contains( snapchatReg )     -> "https://www.snapchat.com/..."
        link.contains( tiktokReg )       -> "https://www.tiktok.com/..."
        link.contains( soundcloudReg )   -> "https://www.soundcloud.com/..."
        else                             -> formatLinks( link )
    }
}

fun _verfifiedLinks( link: String ): Boolean {
    return when {
        link.contains( youtubeReg )      -> true
        link.contains( instagramReg )    -> true
        link.contains( facebookReg )     -> true
        link.contains( spotifyReg )      -> true
        link.contains( twitchReg)        -> true
        link.contains( twitterReg )      -> true
        link.contains( redditReg )       -> true
        link.contains( podcastReg )      -> true
        link.contains( snapchatReg )     -> true
        link.contains( tiktokReg )       -> true
        link.contains( soundcloudReg )   -> true
        link.contains(musicReg )         -> true
        else                             -> false
    }
}

private fun formatLinks( link: String ): String {
    if( link.length > 30 ){
        var tmpLink = ""
        var ic = 0
        while ( ic < link.length ){
            tmpLink += link[ic]
            ic++
        }
        return tmpLink
    }

    return link
}