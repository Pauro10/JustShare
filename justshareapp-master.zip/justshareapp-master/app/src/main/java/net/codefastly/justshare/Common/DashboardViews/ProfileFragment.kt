package net.codefastly.justshare.Common.DashboardViews

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.Navigation
import androidx.recyclerview.widget.StaggeredGridLayoutManager
import net.codefastly.justshare.HelperClasses.FirebaseUserAdapter
import net.codefastly.justshare.R
import net.codefastly.justshare.databinding.FragmentProfileBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.database.*

import net.codefastly.justshare.Common.Controllers.ProfileFragmentVM
import net.codefastly.justshare.Models.FirebasePublication
import com.squareup.picasso.Picasso
import net.codefastly.justshare.Common.DashboardActivity
import net.codefastly.justshare.NavGraphDirections
import net.codefastly.justshare.Utils.snack

class ProfileFragment : Fragment() {

    private lateinit var binding: FragmentProfileBinding

    var usersReference: DatabaseReference? = null
    var firebaseUser: FirebaseUser? = null
    private lateinit var currentUserUid : String

    private val GALLERY_PICKUP_CODE = 1122

    // Inicializamos viewModel cuando lo necesitamos
    private val viewModel by lazy { ViewModelProvider(this).get(ProfileFragmentVM::class.java) }

    private lateinit var userAdapter: FirebaseUserAdapter


    private var publication: FirebasePublication? = null

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        firebaseUser = FirebaseAuth.getInstance().currentUser
        usersReference = FirebaseDatabase.getInstance().getReference("USER")

        // Inflate the layout for this fragment
        this.binding = DataBindingUtil.inflate(inflater, R.layout.fragment_profile, container, false)

        this.currentUserUid = requireActivity().getSharedPreferences(getString(R.string.prefs_file), Context.MODE_PRIVATE).getString("currentUid", "").toString()

        this.cargaDetalles()
        this.initProfileRecycler()

        var database = FirebaseDatabase.getInstance().reference

        var getdata = object : ValueEventListener{
                override fun onDataChange(dataSnapshot: DataSnapshot) {
                }

            override fun onCancelled(error: DatabaseError) {
            }
        }
        database.addValueEventListener(getdata)
        database.addListenerForSingleValueEvent(getdata)

        this.binding.btnChangeImage.setOnClickListener {
            this.changeProfileImage()
        }

        this.binding.btnBack.setOnClickListener {
            //getFragmentManager()?.popBackStack()
            (activity as DashboardActivity).setBottomMenuNavigation(true)
            val action = NavGraphDirections.actionToHomeFragment()
            Navigation.findNavController(it).navigate(action)
        }

        return this.binding.root
    }

    private fun cargaDetalles(){
        this.binding.tvNumClicks.text = this.publication?.click.toString()

    }

    private fun initProfileRecycler(){
        this.binding.rvUser.layoutManager = StaggeredGridLayoutManager(2, StaggeredGridLayoutManager.VERTICAL)
        this.userAdapter = FirebaseUserAdapter( requireContext() )
        this.binding.rvUser.adapter = this.userAdapter

        this.observePublicationProfileData()
    }

    private fun observePublicationProfileData(){
        this.viewModel.fetchUserData(this.currentUserUid).observe(viewLifecycleOwner, Observer { usuario ->
            this.binding.tvNickname.text = usuario.username

            this.viewModel.fetchPublicationProfileData(this.currentUserUid).observe( viewLifecycleOwner, Observer { observePublicacions ->
                this.userAdapter.setListData( observePublicacions )
                this.userAdapter.notifyDataSetChanged()})
            if(usuario.profileImage.isEmpty()){
                Picasso.get().load(requireContext().getString(R.string.profile_image_link)).into(this.binding.ivUser)
            }else{
                Picasso.get().load(usuario.profileImage).into(this.binding.ivUser)
            }
        })
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        // Change Image Peview to Choosed Image
        if (requestCode == GALLERY_PICKUP_CODE && resultCode == Activity.RESULT_OK && data!!.data != null){
            val imageUri = data.data

            requireView().snack(getString(R.string.profile_fragment_imgact))

            if (imageUri != null) {
                this.viewModel.uploadImageToFirebase( imageUri, this.currentUserUid )
            }

            // Show imagen on profile
            this.binding.ivUser.setImageURI( imageUri )
        }
    }

    /*------------- CHANGE PROFILE IMAGE ---------------*/

    private fun changeProfileImage(){
        // Open Activity for pick image from GALLERY
        pickImage()
    }

    private fun pickImage(){
        val intent = Intent()
        intent.type = "image/*"
        intent.action = Intent.ACTION_GET_CONTENT
        startActivityForResult(intent, GALLERY_PICKUP_CODE)
    }





}