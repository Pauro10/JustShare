package net.codefastly.justshare.Models

class Profile (
    var user_id: String,
    var username: String
)

