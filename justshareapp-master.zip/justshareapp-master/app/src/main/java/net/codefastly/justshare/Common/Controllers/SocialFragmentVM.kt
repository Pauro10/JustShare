package net.codefastly.justshare.Common.Controllers


import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import net.codefastly.justshare.Models.FollowingItem
import net.codefastly.justshare.Models.SocialPublication
import net.codefastly.justshare.NetworkData.Repository

class SocialFragmentVM: ViewModel() {

    private val repo = Repository()

    /*
    fun fetchSocialPublicationsData(): LiveData<MutableList<SocialPublication>> {

        val mutableData = MutableLiveData<MutableList<SocialPublication>>()
        repo.fetchSocialPublicationsData().observeForever { SocialPublicationList ->
            mutableData.value = SocialPublicationList
        }

        return mutableData
    }
     */

    fun fetchSocialPublicationsData(): LiveData<MutableList<SocialPublication>>{

        val mutableData = MutableLiveData<MutableList<SocialPublication>>()
        repo.getListPublications().observeForever { listPublications ->
            repo.getSocialPublications( listPublications ).observeForever { listSocialItems ->
                mutableData.value = listSocialItems
            }
        }


        return mutableData
    }


}