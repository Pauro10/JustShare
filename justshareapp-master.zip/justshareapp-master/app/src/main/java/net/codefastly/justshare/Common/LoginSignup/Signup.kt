package net.codefastly.justshare.Common.LoginSignup


import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import androidx.databinding.DataBindingUtil
import net.codefastly.justshare.R
import net.codefastly.justshare.Utils.snack
import net.codefastly.justshare.databinding.ActivitySignupBinding
import kotlinx.android.synthetic.main.activity_signup.view.*

class Signup : AppCompatActivity() {

    private lateinit var binding: ActivitySignupBinding


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        this.binding = DataBindingUtil.setContentView(this, R.layout.activity_signup)

        fullScreenMode()

        // LISTENERS

        // Back Screen
        this.binding.btnSignUpBack.setOnClickListener {
            changeScreen(it, 0)
        }

        // Next Signup Screen
        this.binding.btnContinue.setOnClickListener {

            if( !validateFields(it) ){
                return@setOnClickListener
            }

            // Fields are validated
            changeScreen(it, 1)
        }

        // Login Screen
        this.binding.btnLogin.setOnClickListener {
            changeScreen(it, 2)
        }


    }

    private fun changeScreen( view: View, option: Int ){

        var intent = Intent()

        when(option){
            0 -> {
                // Atrás
                intent = Intent( applicationContext, RetailerStartUpScreen::class.java )
            }
            1 -> {
                // Siguiente
                intent = Intent( applicationContext, SignupSecond::class.java ).apply {
                    // Preparamos los datos del usuario
                    this.putExtra("EXTRA_SESSION_USERNAME", binding.tfUsername.text.toString() )
                    this.putExtra("EXTRA_SESSION_EMAIL", binding.tfMail.text.toString() )
                    this.putExtra("EXTRA_SESSION_PASSWORD", binding.tfPass.text.toString() )
                    this.putExtra("EXTRA_SESSION_FULLNAME", binding.tfFullname.text.toString() )
                }
            }
            2 -> {
                // Login
                intent = Intent( applicationContext, Login::class.java )
            }
        }

        startActivity(intent)
        if( option == 0 ){
            overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right)
        }else{
            overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left)
        }
        finish()
    }

    private fun validateFields(view: View): Boolean {

        val EMAIL_REGEX = "^[A-Za-z](.*)([@]{1})(.{1,})(\\.)(.{1,})"

        // Validate password
        return if( this.binding.tfPass.text.toString() == "" || this.binding.tfPass.text.toString().length < 6 ) {
            view.snack(getString(R.string.signup_pass))
            false
        } else if( this.binding.tfMail.text.toString() == "" || !this.binding.tfMail.text.toString().contains(regex = EMAIL_REGEX.toRegex())) {
            view.snack(getString(R.string.login_emailvalid))
            false
        } else if( this.binding.tfUsername.text.toString() == "" ) {
            view.snack(getString(R.string.signup_username))
            false
        } else if( this.binding.tfFullname.text.toString() == "" ) {
            view.snack(getString(R.string.signup_name))
            false
        } else{
            true
        }

    }

    private fun  fullScreenMode(){
        // Hide actionBar and fullScreen mode
        supportActionBar?.hide()
        window.setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN)
    }


}

