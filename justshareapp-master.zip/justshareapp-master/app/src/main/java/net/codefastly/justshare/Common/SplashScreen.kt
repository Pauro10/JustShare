package net.codefastly.justshare.Common

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.res.Configuration
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import android.view.WindowManager
import android.view.animation.Animation
import android.view.animation.AnimationUtils
import android.widget.ImageView
import android.widget.TextView
import net.codefastly.justshare.Common.LoginSignup.RetailerStartUpScreen
import net.codefastly.justshare.R
import java.util.*

class SplashScreen : AppCompatActivity() {

    private val SPLASH_TIMER: Long = 5000

    // Variables
    private lateinit var backgroundImage: ImageView
    private lateinit var poweredByLine: TextView

    // Animations
    private lateinit var sideAnim : Animation
    private lateinit var bottomAnim : Animation

    lateinit var onBoardingScreen: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        fullScreenMode()
        setContentView(R.layout.activity_splash_screen)

        // Cargamos idioma seleccionado por el usuario
        loadLocate()

        // Hooks
        backgroundImage = findViewById(R.id.background_image)
        poweredByLine = findViewById(R.id.powered_by_line)

        // Animations
        sideAnim = AnimationUtils.loadAnimation(this, R.anim.side_anim)
        bottomAnim = AnimationUtils.loadAnimation(this, R.anim.bottom_anim)

        // set Animations on elements
        backgroundImage.animation = sideAnim
        poweredByLine.animation = bottomAnim

        Handler().postDelayed({
            var intent: Intent
            if (getSharedPreferences(getString(R.string.prefs_file), Context.MODE_PRIVATE).getBoolean("rememberOption", false)){
                 intent = Intent(applicationContext, DashboardActivity::class.java)
            } else {
                if (getSharedPreferences(getString(R.string.prefs_file), Context.MODE_PRIVATE).getBoolean("skipOption", false)){
                    intent = Intent(applicationContext, RetailerStartUpScreen::class.java)
                } else {
                    intent = Intent(applicationContext, OnBoarding::class.java)
                }

            }
                startActivity(intent)
                overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left)
                finish()

        }, SPLASH_TIMER)

    }

    private fun  fullScreenMode(){
        // Hide actionBar and fullScreen mode
        supportActionBar?.hide()
        window.setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN)
    }

    /*private fun checkPreferences(): Boolean{
        val prefs = getSharedPreferences(getString(R.string.prefs_file), Context.MODE_PRIVATE)
        return prefs.getString("UID", null) != null
    }*/

    private fun setLocale(language: String){
        val locale = Locale(language)
        Locale.setDefault(locale)

        val config = Configuration()
        config.locale = locale
        this.baseContext.resources.updateConfiguration(config, baseContext.resources.displayMetrics )

        val editor = this.getSharedPreferences("Settings", Activity.MODE_PRIVATE ).edit()
        editor.putString("My_Lang", language)
        editor.apply()
    }

    private fun loadLocate() {
        val sharedPreferences = this.getSharedPreferences("Settings", Activity.MODE_PRIVATE)
        val language = sharedPreferences.getString("My_Lang", "")
        if (language != null) {
            setLocale(language)
        }
    }


}