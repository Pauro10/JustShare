package net.codefastly.justshare.Common.Controllers

import android.net.Uri
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import net.codefastly.justshare.Models.*
import net.codefastly.justshare.NetworkData.Repository


class ProfileFragmentVM: ViewModel() {

        private val repo = Repository()

        fun fetchProfileData(): LiveData<MutableList<User>> {
            // Cuando este mutable live data tenga información el metodo fetch lo retornará
            val mutableData = MutableLiveData<MutableList<User>>()
            // Va a estar escuchando hasta que se entren datos
            repo.getUserData().observeForever { userList ->
                mutableData.value = userList
            }

            return mutableData
        }


        fun fetchPublicationProfileData(uid: String): LiveData<MutableList<FirebasePublication>> {

            val mutableData = MutableLiveData<MutableList<FirebasePublication>>()
            repo.getPublicationsByUid(uid).observeForever { publicationList ->
                mutableData.value = publicationList
            }

            return mutableData
        }

        fun fetchUserData(uid: String): LiveData<net.codefastly.justshare.Models.FirebaseUser> {

            val mutableData = MutableLiveData<net.codefastly.justshare.Models.FirebaseUser>()
            repo.getUserDataByUid(uid).observeForever{ usuario ->

                    mutableData.value = usuario
            }
            return mutableData
        }

        fun uploadImageToFirebase( imageUri: Uri , uid: String ){
            this.repo.putImageToStorage( imageUri, uid )
        }


    }
