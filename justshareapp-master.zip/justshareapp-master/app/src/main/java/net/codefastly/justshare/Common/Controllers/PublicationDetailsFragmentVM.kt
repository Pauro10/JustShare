package net.codefastly.justshare.Common.Controllers

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import net.codefastly.justshare.Models.Comment
import net.codefastly.justshare.NetworkData.Repository

class PublicationDetailsFragmentVM : ViewModel(){

    private val repo = Repository()

    /*
    * fun fetchPublicationCommentsssssss( publication_id : String ): MutableLiveData<MutableList<Comment>>{
        val mutableData = MutableLiveData<MutableList<Comment>>()

        repo.getPublicationComments( publication_id ).observeForever { comments ->
            mutableData.value = comments
        }
        return mutableData
    }
    * */

    /*  RECOGEMOS TODOS LOS COMENTARIOS */
    fun fetchPublicationComments( publicationId: String ): LiveData<MutableList<Comment>> {

        val mutableData = MutableLiveData<MutableList<Comment>>()
        repo.getListOfComments( publicationId ).observeForever { mutableListComments ->
            repo.getPublicationComments( mutableListComments ).observeForever { mutableListComment ->
                mutableData.value = mutableListComment
            }
        }

        return mutableData
    }

    fun fetchUsernamePublication(userpubli: String): LiveData<net.codefastly.justshare.Models.FirebaseUser>{

        val mutableData = MutableLiveData<net.codefastly.justshare.Models.FirebaseUser>()
        repo.getUserDataByUid(userpubli).observeForever{mutableListUsername ->

            mutableData.value = mutableListUsername

        }
        return mutableData
    }


}