package net.codefastly.justshare.NetworkData

import android.net.Uri
import android.os.Build
import android.util.Log
import androidx.annotation.RequiresApi
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.google.android.gms.tasks.Continuation
import com.google.android.gms.tasks.Task
import net.codefastly.justshare.Models.*
import com.google.firebase.database.*
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.StorageReference
import com.google.firebase.storage.StorageTask
import com.google.firebase.storage.UploadTask
import java.time.LocalDateTime

class Repository {

    private lateinit var ref: DatabaseReference

    private lateinit var storageRef: StorageReference

    fun getUserData(): LiveData<MutableList<User>>{
        val mutableData = MutableLiveData<MutableList<User>>()

        // Cargamos la información de firebase
        ref = FirebaseDatabase.getInstance().reference.child("USER")
        ref.addValueEventListener( object: ValueEventListener{

            @RequiresApi(Build.VERSION_CODES.O)
            override fun onDataChange(snapshot: DataSnapshot) {
                if( snapshot.exists() ){
                val listData = mutableListOf<User>()
                for ( item in snapshot.children ){
                    val username = item.child("username").value.toString()
                    val pImage = item.child("profileImage").value.toString()
                    // Generamos el objeto y lo introducimos en la lista
                    val objUser = User("",username,"","","","","", profileImage = pImage )
                    listData.add(objUser)
                }
                // Hacemos el intercambio de información
                mutableData.value = listData
            }

            }

            override fun onCancelled(error: DatabaseError) {
                // Failed to read value
                Log.w("FirebaseError: ","Failed to read value.", error.toException() )
            }
        })


        return mutableData
    }


    fun getPublicationData(): LiveData<MutableList<FirebasePublication>>{
        val mutableData = MutableLiveData<MutableList<FirebasePublication>>()

        this.ref = FirebaseDatabase.getInstance().reference.child("PUBLICATION")
        this.ref.addValueEventListener( object: ValueEventListener{
            @RequiresApi(Build.VERSION_CODES.O)
            override fun onDataChange(snapshot: DataSnapshot) {
                if (snapshot.exists()){
                    val listData = mutableListOf<FirebasePublication>()
                    for ( pub in snapshot.children) {
                        val urlImage = pub.child("imageUrl").value.toString()
                        val url = pub.child("url").value.toString()
                        val categories = pub.child("categories").value.toString()
                        val click = pub.child("click").value.toString()
                        //val creationDate = pub.child("creationDate").child("dayOfMonth").value.toString()
                        val description = pub.child("description").value.toString()
                        val owner = pub.child("owner").value.toString()


                        val firebasePublication = FirebasePublication(
                                                                        id = pub.key!!, categories = categories,
                                                                        click = click.toInt(), creationDate = LocalDateTime.now(),
                                                                        description = description, imageUrl = urlImage,
                                                                        owner = owner, url = url
                                                                     )
                        listData.add(firebasePublication)
                    }
                    mutableData.value = listData
                }
            }

            override fun onCancelled(error: DatabaseError) {
                // Failed to read value
                Log.w("FirebaseError: ","Failed to read value.", error.toException() )
            }

        })

        return mutableData
    }


    fun getMapUsers(): LiveData<MutableMap<String, FirebaseUser>> {

        var mutableData = MutableLiveData<MutableMap<String, FirebaseUser>>()

        this.ref = FirebaseDatabase.getInstance().reference.child("USER")
        this.ref.addValueEventListener( object: ValueEventListener{
            @RequiresApi(Build.VERSION_CODES.O)
            override fun onDataChange(snapshot: DataSnapshot) {
                if( snapshot.exists() ){
                    val mapData = mutableMapOf<String, FirebaseUser>()
                    for ( user in snapshot.children ){
                        val username = user.child("username").value.toString()
                        val imgProfile = user.child("profileImage").value.toString()
                        val birthday = user.child("birthday").value.toString()
                        val countryCode = user.child("countryCode").value.toString()
                        val fullName = user.child("fullName").value.toString()
                        val gender = user.child("gender").value.toString()
                        val phoneNumber = user.child("phoneNumber").value.toString()
                        Log.w("Username", username)

                        val obj = FirebaseUser(
                            username = username,
                            profileImage = imgProfile,
                            birthday = birthday,
                            countryCode = countryCode,
                            fullName = fullName,
                            gender = gender,
                            phoneNumber = phoneNumber,
                            id = user.key!!,
                            password = "")
                        mapData[user.key!!] = obj
                    }
                    mutableData.value = mapData
                }
            }

            override fun onCancelled(error: DatabaseError) {
                // Failed to read value
                Log.w("FirebaseError: ","Failed to read value.", error.toException() )
            }
        })


        return mutableData
    }


    fun getFollowingItemsByUsers( mapUsers: MutableMap<String, FirebaseUser> ): LiveData<MutableList<FollowingItem>> {

        val mutableData = MutableLiveData<MutableList<FollowingItem>>()

        this.ref = FirebaseDatabase.getInstance().reference.child("PUBLICATION")

        val listData = mutableListOf<FollowingItem>()
        for ( user in mapUsers ){
            Log.w("key", user.key)
            this.ref.orderByChild("owner").limitToLast(1).equalTo( user.key ).addValueEventListener( object: ValueEventListener{
                @RequiresApi(Build.VERSION_CODES.O)
                override fun onDataChange(snapshot: DataSnapshot) {
                    if( snapshot.exists() ){
                        for( publication in snapshot.children ) {
                            val urlImage = publication.child("imageUrl").value.toString()
                            val url = publication.child("url").value.toString()
                            val categories = publication.child("categories").value.toString()
                            val click = publication.child("click").value.toString()
                            val description = publication.child("description").value.toString()
                            val owner = publication.child("owner").value.toString()

                            val obj = FirebasePublication(id = publication.key!!, categories = categories, click = click.toInt(),
                                description = description, owner = owner, url = url, imageUrl = urlImage, creationDate = LocalDateTime.now())

                            val objFollowingItem = FollowingItem( user = user.value, publication = obj )
                            listData.add(objFollowingItem)

                        }
                    }
                }

                override fun onCancelled(error: DatabaseError) {
                    // Failed to read value
                    Log.w("FirebaseError: ","Failed to read value.", error.toException() )
                }
            })
        }
        mutableData.value = listData

        return mutableData
    }



    /*
    * RECOGEMOS TODOS LOS COMENTARIOS EN MAP
    * */

    fun getListOfComments( publicationId: String ): LiveData<MutableList<Comment>> {
        val mutableData = MutableLiveData<MutableList<Comment>>()

        this.ref = FirebaseDatabase.getInstance().reference.child("COMMENT")

        this.ref.orderByChild("publication_id").equalTo( publicationId ).addValueEventListener( object: ValueEventListener{
            @RequiresApi(Build.VERSION_CODES.O)
            override fun onDataChange(snapshot: DataSnapshot) {
                if( snapshot.exists() ){
                    val mapData = mutableListOf<Comment>()
                    for ( comment in snapshot.children ){
                        val idUser = comment.child("user_id").value.toString()
                        val idPublication = comment.child("publication_id").value.toString()
                        val message = comment.child("text").value.toString()

                        val objComment = Comment(user_id = idUser , publication_id = idPublication, username = "", userImage = "", id = comment.key!!, text = message)
                        mapData.add(objComment)
                    }
                    mutableData.value = mapData
                }
            }

            override fun onCancelled(error: DatabaseError) {
                // Failed to read value
                Log.w("FirebaseError: ","Failed to read value.", error.toException() )
            }
        })


        return mutableData
    }

    /*
    * RECOGEMOS INFORMACIÓN DE USUARIO Y CARGAMOS COMENTARIOS
    * */

    fun getPublicationComments( listComments: MutableList<Comment> ): LiveData<MutableList<Comment>> {

        val mutableData = MutableLiveData<MutableList<Comment>>()

        this.ref = FirebaseDatabase.getInstance().reference.child("USER")

        val listData = mutableListOf<Comment>()
        for ( comment in listComments ){

            this.ref.orderByKey().equalTo( comment.user_id ).addValueEventListener( object: ValueEventListener{
                override fun onDataChange(snapshot: DataSnapshot) {
                    if( snapshot.exists() ){
                        for( user in snapshot.children ) {
                            val userImage = user.child("profileImage").value.toString()
                            val username = user.child("username").value.toString()

                            comment.userImage = userImage
                            comment.username = username

                            listData.add(comment)
                        }
                        mutableData.value = listData
                    }
                }

                override fun onCancelled(error: DatabaseError) {
                    // Failed to read value
                    Log.w("FirebaseError: ","Failed to read value.", error.toException() )
                }
            })
        }

        return mutableData
    }

    //Recogemos publicaciones de un usuario
    fun getPublicationsByUid(uid: String): LiveData<MutableList<FirebasePublication>>{
        val mutableData = MutableLiveData<MutableList<FirebasePublication>>()

        this.ref = FirebaseDatabase.getInstance().reference.child("PUBLICATION")
        this.ref.orderByChild("owner").equalTo(uid).addValueEventListener(object: ValueEventListener{
            override fun onCancelled(error: DatabaseError) {
                // Failed to read value
                Log.w("FirebaseError: ","Failed to read value.", error.toException() )
            }

            @RequiresApi(Build.VERSION_CODES.O)
            override fun onDataChange(snapshot: DataSnapshot) {
                if(snapshot.exists()){
                    val listData = mutableListOf<FirebasePublication>()
                    for(publication in snapshot.children){
                        val urlImage = publication.child("imageUrl").value.toString()
                        val url = publication.child("url").value.toString()
                        val categories = publication.child("categories").value.toString()
                        val click = publication.child("click").value.toString()
                        val description = publication.child("description").value.toString()
                        val owner = publication.child("owner").value.toString()

                        val obj = FirebasePublication(id = publication.key!!, categories = categories, click = click.toInt(),
                            description = description, owner = owner, url = url, imageUrl = urlImage, creationDate = LocalDateTime.now())
                        listData.add(obj)
                    }
                    mutableData.value = listData
                }
            }

        })
        return mutableData
    }

    //Recogemos usuario por userId
    fun getUserDataByUid(uid: String): LiveData<FirebaseUser> {
        val mutableData = MutableLiveData<FirebaseUser>()
        Log.w("uidRecibida", uid)

        this.ref = FirebaseDatabase.getInstance().reference.child("USER")
        this.ref.orderByKey().equalTo(uid).addListenerForSingleValueEvent(object: ValueEventListener {
            override fun onCancelled(error: DatabaseError) {
                // Failed to read value
                Log.w("FirebaseError: ", "Failed to read value.", error.toException())
            }

            override fun onDataChange(snapshot: DataSnapshot) {
                if (snapshot.exists()) {
                    snapshot.children.forEach { user ->
                        val username = user.child("username").value.toString()
                        val imgProfile = user.child("profileImage").value.toString()
                        val birthday = user.child("birthday").value.toString()
                        val countryCode = user.child("countryCode").value.toString()
                        val fullName = user.child("fullName").value.toString()
                        val gender = user.child("gender").value.toString()
                        val phoneNumber = user.child("phoneNumber").value.toString()
                        Log.w("Username", username)

                        val obj = FirebaseUser(
                            username = username,
                            profileImage = imgProfile,
                            birthday = birthday,
                            countryCode = countryCode,
                            fullName = fullName,
                            gender = gender,
                            phoneNumber = phoneNumber,
                            id = user.key!!,
                            password = "")
                        mutableData.value = obj
                    }
                }//Termina condicion if exists
            }//OnDataChange
        })//Termina ValueEventListener
        return mutableData
    }//Termina funcion


    fun getListPublications(): LiveData<MutableList<FirebasePublication>> {

        var mutableData = MutableLiveData<MutableList<FirebasePublication>>()

        this.ref = FirebaseDatabase.getInstance().reference.child("PUBLICATION")
        this.ref.addValueEventListener( object: ValueEventListener{
            @RequiresApi(Build.VERSION_CODES.O)
            override fun onDataChange(snapshot: DataSnapshot) {
                if( snapshot.exists() ){
                    val mapList = mutableListOf<FirebasePublication>()
                        for( publication in snapshot.children ){
                            val urlImage = publication.child("imageUrl").value.toString()
                            val url = publication.child("url").value.toString()
                            val categories = publication.child("categories").value.toString()
                            val click = publication.child("click").value.toString()
                            val description = publication.child("description").value.toString()
                            val owner = publication.child("owner").value.toString()

                            val objPublication = FirebasePublication(id = publication.key!!, categories = categories, click = click.toInt(),
                                description = description, owner = owner, url = url, imageUrl = urlImage, creationDate = LocalDateTime.now())
                            mapList.add(objPublication)
                        }
                        mutableData.value = mapList
                    }
                }

            override fun onCancelled(error: DatabaseError) {
                // Failed to read value
                Log.w("FirebaseError: ","Failed to read value.", error.toException() )
            }
        })

        return mutableData
    }


    /*
   * RECOGEMOS INFORMACIÓN DE PUBLICACIÓN Y CARGAMOS USUARIO
   * */

    fun getSocialPublications( listPublication: MutableList<FirebasePublication> ): LiveData<MutableList<SocialPublication>> {

        val mutableData = MutableLiveData<MutableList<SocialPublication>>()

        this.ref = FirebaseDatabase.getInstance().reference.child("USER")

        val listData = mutableListOf<SocialPublication>()
        for ( publication in listPublication ){

            this.ref.orderByKey().equalTo( publication.owner ).addValueEventListener( object: ValueEventListener{
                override fun onDataChange(snapshot: DataSnapshot) {
                    if( snapshot.exists() ){
                        for( user in snapshot.children ) {

                            val username = user.child("username").value.toString()
                            val imgProfile = user.child("profileImage").value.toString()
                            val birthday = user.child("birthday").value.toString()
                            val countryCode = user.child("countryCode").value.toString()
                            val fullName = user.child("fullName").value.toString()
                            val gender = user.child("gender").value.toString()
                            val phoneNumber = user.child("phoneNumber").value.toString()

                            val objUser = FirebaseUser(
                                username = username,
                                profileImage = imgProfile,
                                birthday = birthday,
                                countryCode = countryCode,
                                fullName = fullName,
                                gender = gender,
                                phoneNumber = phoneNumber,
                                id = user.key!!,
                                password = "")
                            val socialObj = SocialPublication(publication, objUser)

                            listData.add(socialObj)
                        }
                        mutableData.value = listData
                    }
                }

                override fun onCancelled(error: DatabaseError) {
                    // Failed to read value
                    Log.w("FirebaseError: ","Failed to read value.", error.toException() )
                }
            })
        }
        //mutableData.value = listData

        return mutableData
    }



    /*------------------------------- UPLOAD TASKS -------------------------------*/
    fun putImageToStorage( imageUri: Uri, userId: String ) {

        var imageLink = ""

        this.storageRef = FirebaseStorage.getInstance().reference.child("User Images")
        val fileRef = storageRef.child(System.currentTimeMillis().toString() + ".jpg")
        val uploadTask: StorageTask<*>

        uploadTask = fileRef.putFile( imageUri )

        uploadTask.continueWithTask(Continuation <UploadTask.TaskSnapshot, Task<Uri>> { task ->
            if(!task.isSuccessful){
                task.exception?.let {
                    throw it
                }
            }
            return@Continuation fileRef.downloadUrl
        }).addOnCompleteListener{ task ->
            if (task.isSuccessful){

                imageLink = task.result.toString()
                putNewProfileImage( imageLink, userId )

            }
        }

    }

    private fun putNewProfileImage( imageLink: String, uid: String ) {
        this.ref = FirebaseDatabase.getInstance().reference.child("USER")
        this.ref.orderByKey().equalTo( uid ).addListenerForSingleValueEvent( object: ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                if ( snapshot.exists() ){
                    Log.w("SubidaImagen", "$imageLink --> $uid")
                    snapshot.ref.child("$uid/profileImage").setValue( imageLink )

                }
            }

            override fun onCancelled(error: DatabaseError) {
                // Failed to read value
                Log.w("FirebaseError: ","Failed to read value.", error.toException() )
            }

        })
    }



}