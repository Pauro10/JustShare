package net.codefastly.justshare.Common

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import androidx.viewpager2.widget.ViewPager2
import net.codefastly.justshare.Common.LoginSignup.RetailerStartUpScreen
import net.codefastly.justshare.HelperClasses.ViewPagerAdapter
import net.codefastly.justshare.R
import kotlinx.android.synthetic.main.activity_on_boarding.*
import me.relex.circleindicator.CircleIndicator3



class OnBoarding : AppCompatActivity() {

    // Variables
    private var headingsList = mutableListOf<String>()
    private var descriptionsList = mutableListOf<String>()
    private var imagesList = mutableListOf<Int>()


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        fullScreenMode()
        setContentView(R.layout.activity_on_boarding)

        postToList()

         slider.adapter = ViewPagerAdapter(headingsList, descriptionsList, imagesList)

         slider.orientation = ViewPager2.ORIENTATION_HORIZONTAL

        val indicator = findViewById<CircleIndicator3>(R.id.indicator)
        indicator.setViewPager(slider)

        get_started_btn.setOnClickListener {
            val intent = Intent(applicationContext, RetailerStartUpScreen::class.java)
            startActivity(intent)
            overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left)
            finish()
        }

        


    }



    fun skip(view: View){
        //Save user preferences
        val prefs = getSharedPreferences(getString(R.string.prefs_file), Context.MODE_PRIVATE).edit()
        prefs.putBoolean("skipOption", true)
        prefs.apply()
        // Function for btn_skip on XML
        startActivity(Intent(this, RetailerStartUpScreen::class.java))

    }

    fun next(view: View){
        slider.currentItem = (slider.currentItem + 1)
    }


    private fun addToList( heading: String, description: String, image: Int ){
        headingsList.add(heading)
        descriptionsList.add(description)
        imagesList.add(image)
    }

    private fun postToList(){
        addToList( getString(R.string.first_slide_title), getString(R.string.first_slide_desc), R.drawable.search_place  )
        addToList( getString(R.string.second_slide_title), getString(R.string.second_slide_desc), R.drawable.add_missing_place  )
        addToList( getString(R.string.third_slide_title), getString(R.string.third_slide_desc), R.drawable.make_a_call )
        addToList( getString(R.string.fourth_slide_title), getString(R.string.fourth_slide_desc), R.drawable.sit_back_and_relax  )
    }

    private fun  fullScreenMode(){
        // Hide actionBar and fullScreen mode
        supportActionBar?.hide()
        window.setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN)
    }

}