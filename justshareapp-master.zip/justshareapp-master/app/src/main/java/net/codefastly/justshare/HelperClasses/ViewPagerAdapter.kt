package net.codefastly.justshare.HelperClasses


import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.recyclerview.widget.RecyclerView
import net.codefastly.justshare.R


class ViewPagerAdapter(private var headings: List<String>, private var descriptions: List<String>, private var images: List<Int> ): RecyclerView.Adapter<ViewPagerAdapter.Pager2ViewHolder>() {

    private var position: Int = 0

    inner class Pager2ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView){
        val itemHeading: TextView = itemView.findViewById(R.id.slider_heading)
        val itemDescription: TextView = itemView.findViewById(R.id.slider_desc)
        val itemImage: ImageView = itemView.findViewById(R.id.slider_image)

    }

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
        ): Pager2ViewHolder {

        return Pager2ViewHolder(LayoutInflater.from(parent.context).inflate(R.layout.slides_layout, parent, false))
    }

    override fun getItemCount(): Int {
        return headings.size
    }

    override fun onBindViewHolder(holder: Pager2ViewHolder, position: Int) {
        holder.itemHeading.text = headings[position]
        holder.itemDescription.text = descriptions[position]
        holder.itemImage.setImageResource(images[position])
        this.position = position
    }

    fun getPosition(): Int{
        return this.position
    }




}




