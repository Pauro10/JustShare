package net.codefastly.justshare.Models

data class FollowingItem(
    val user: FirebaseUser,
    val publication: FirebasePublication
    ) {
        /*
        * val username: String,
    val profileImage: String,
    val publicationImage: String,
    val publicationUrl: String*/
    }