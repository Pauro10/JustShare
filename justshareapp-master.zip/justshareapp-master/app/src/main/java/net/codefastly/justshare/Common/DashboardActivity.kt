package net.codefastly.justshare.Common

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import androidx.core.view.isInvisible
import androidx.databinding.DataBindingUtil
import androidx.navigation.findNavController
import net.codefastly.justshare.Dialogs.SettingsDialogFragment
import net.codefastly.justshare.NavGraphDirections
import net.codefastly.justshare.R
import net.codefastly.justshare.databinding.ActivityDashboardBinding

class DashboardActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDashboardBinding


    @SuppressLint("ResourceType")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        this.binding = DataBindingUtil.setContentView(this, R.layout.activity_dashboard)

        fullScreenMode()

        // Paint Home Icon ( Default onStart )
        this.changeBottomMenuIcon(0)

        // LISTENERS

        // Settings Dialog
        this.binding.btnSettings.setOnClickListener {
            val dialog = SettingsDialogFragment()
            dialog.show(supportFragmentManager, "settingsDialog")
        }

        // Home Screen
        this.binding.btnHome.setOnClickListener {
            // Navegamos hacie el fragment home
            findNavController(R.id.fragmentContainer).navigate(R.id.action_to_homeFragment)
            this.changeBottomMenuIcon(0)
        }

        // Trends Screen
        this.binding.btnTrends.setOnClickListener {
            // Navegamos hacie el fragment trends
            findNavController(R.id.fragmentContainer).navigate(R.id.action_to_trendsFragment)
            this.changeBottomMenuIcon(1)
        }

        // Add Screen
        this.binding.btnAdd.setOnClickListener {
            // Navegamos hacie el fragment de creación
            findNavController(R.id.fragmentContainer).navigate(R.id.action_to_addFragment)
            this.changeBottomMenuIcon(2)
        }

        // Social Screen
        this.binding.btnSocial.setOnClickListener {
            // Navegamos hacie el fragment social
            findNavController(R.id.fragmentContainer).navigate(R.id.action_to_socialFragment)
            this.changeBottomMenuIcon(3)
        }

        // Notifications Screen
        this.binding.btnNotify.setOnClickListener {
            // Navegamos hacie el fragment notifcations
            findNavController(R.id.fragmentContainer).navigate(R.id.action_to_notificationFragment)
            this.changeBottomMenuIcon(4)
        }

        // Profile Screen
        this.binding.btnProfile.setOnClickListener {
            // Navegamos hacie el fragment profile
            findNavController(R.id.fragmentContainer).navigate(R.id.action_to_profileFragment)
            this.changeBottomMenuIcon(5)

        }

    }

    private fun changeBottomMenuIcon( option: Int ){

        this.binding.btnHome.setImageResource(R.drawable.ic_home_dark)
        this.binding.btnTrends.setImageResource(R.drawable.ic_trends_dark)
        this.binding.btnAdd.setImageResource(R.drawable.ic_add_dark)
        this.binding.btnSocial.setImageResource(R.drawable.ic_social_dark)
        this.binding.btnNotify.setImageResource(R.drawable.ic_notify_dark)
        this.binding.btnProfile.setImageResource(R.drawable.ic_username_icon)


        when(option){
            0 -> this.binding.btnHome.setImageResource(R.drawable.ic_home_yellow)
            1 -> this.binding.btnTrends.setImageResource(R.drawable.ic_trends_yellow)
            2 -> this.binding.btnAdd.setImageResource(R.drawable.ic_add_yellow)
            3 -> this.binding.btnSocial.setImageResource(R.drawable.ic_social_yellow)
            4 -> this.binding.btnNotify.setImageResource(R.drawable.ic_notify_yellow)
            5 -> this.binding.btnProfile.setImageResource(R.drawable.ic_username_icon)
        }
    }

    fun setBottomMenuNavigation( option: Boolean ){
        when(option) {
            true -> this.binding.bottomMenuNavigation.visibility = View.VISIBLE
            false -> this.binding.bottomMenuNavigation.visibility = View.INVISIBLE
        }
    }

    override fun onBackPressed() {
        super.onBackPressed()
        val action = NavGraphDirections.actionToHomeFragment()
        setBottomMenuNavigation(true)
        changeBottomMenuIcon(0)
        findNavController(R.id.fragmentContainer).navigate(action)
    }

    private fun  fullScreenMode(){
        // Hide actionBar and fullScreen mode
        supportActionBar?.hide()
        window.setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN)
    }

}