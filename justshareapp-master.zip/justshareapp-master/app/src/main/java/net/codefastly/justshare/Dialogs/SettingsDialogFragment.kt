package net.codefastly.justshare.Dialogs

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.DialogFragment
import androidx.lifecycle.ViewModelProvider
import net.codefastly.justshare.Common.LoginSignup.Login
import net.codefastly.justshare.R
import net.codefastly.justshare.databinding.FragmentSettingsDialogBinding
import com.google.firebase.auth.FirebaseAuth
import net.codefastly.justshare.Common.Controllers.ProfileFragmentVM
import net.codefastly.justshare.Common.Controllers.SettingsDialogFragmentVM
import net.codefastly.justshare.Utils.snack
import java.util.*


class SettingsDialogFragment : DialogFragment() {

    private lateinit var binding: FragmentSettingsDialogBinding

    private val GALLERY_PICKUP_CODE = 1122
    private lateinit var currentUserUid: String

    // Inicializamos viewModel cuando lo necesitamos
    private val viewModel by lazy { ViewModelProvider(this).get(SettingsDialogFragmentVM::class.java) }


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        this.binding = DataBindingUtil.inflate(inflater, R.layout.fragment_settings_dialog, container, false)

        // Recogemos UID del usuario activo
        this.currentUserUid = requireActivity().getSharedPreferences(getString(R.string.prefs_file), Context.MODE_PRIVATE).getString("currentUid", "").toString()

            // Ocultamos por defecto todos los layouts que no deberían estar visibles
            this.binding.preferencesLayout.visibility = View.GONE
            this.binding.accountLayout.visibility = View.GONE


            // LISTENERS
            /*
            *   Mostramos opciones de preferencia
            **/
            this.binding.btnPreferences.setOnClickListener {
                when(this.binding.preferencesLayout.visibility){
                    0 -> this.binding.preferencesLayout.visibility = View.GONE
                    8 -> this.binding.preferencesLayout.visibility = View.VISIBLE
                }
            }

            /*
            *   Mostramos opciones de cuenta
            **/
            this.binding.btnAccount.setOnClickListener {
                when(this.binding.accountLayout.visibility){
                    0 -> this.binding.accountLayout.visibility = View.GONE
                    8 -> this.binding.accountLayout.visibility = View.VISIBLE
                }
            }

           /*
           *   Compartimos la app
           **/
            this.binding.btnShareApp.setOnClickListener {
                this.shareApp()
            }

            /*
            *   Mostramos opciones para cambiar de idioma
            **/
            this.binding.btnSelectLanguage.setOnClickListener {
                showShangeLangDialog()
            }

            /*
            * Mostramos galeria para cambiar la imagen de perfil
            **/
            this.binding.btnSelectImage.setOnClickListener{
                this.changeProfileImage()
            }

            // LogOut Listener
            this.binding.btnLogOut.setOnClickListener {

                //Borrado de datos
                val prefs = requireActivity().getSharedPreferences(getString(R.string.prefs_file), Context.MODE_PRIVATE).edit()
                prefs.clear()
                prefs.apply()

                FirebaseAuth.getInstance().signOut()
                val intent = Intent(requireContext(), Login::class.java)
                startActivity(intent)
                requireActivity().overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right)
                requireActivity().finish()
            }


        return this.binding.root
    }

    private fun showShangeLangDialog(){

        val listItems = arrayOf(getString(R.string.language_es), getString(R.string.language_ca), getString(R.string.language_gb))
        val mBuilder = AlertDialog.Builder( requireContext() )
        mBuilder.setTitle(getString(R.string.settingsfragment_selectlang))
        mBuilder.setSingleChoiceItems( listItems, -1 ){ dialog, which ->
            when( which ){
                0 -> {
                    this.setLocale("es")
                    requireActivity().recreate()
                }
                1 -> {
                    this.setLocale("")
                    requireActivity().recreate()
                }
                2 -> {
                    this.setLocale("en")
                    requireActivity().recreate()
                }
            }

            dialog.dismiss()
        }
        val mDialog = mBuilder.create()
        mDialog.show()

    }

    private fun setLocale(language: String){
        val locale = Locale(language)
        Locale.setDefault(locale)

        val config = Configuration()
        config.locale = locale
        requireContext().resources.updateConfiguration(config, requireContext().resources.displayMetrics )

        val editor = requireActivity().getSharedPreferences("Settings", Activity.MODE_PRIVATE ).edit()
        editor.putString("My_Lang", language)
        editor.apply()
    }

    private fun shareApp(){
        val intent = Intent(Intent.ACTION_SEND)
        intent.type = "text/plain"
        val body = getString(R.string.dialogfragment_title)
        val link = "https://play.google.com/store/apps/details?id=net.codefastly.justshare"
        intent.putExtra(Intent.EXTRA_TEXT, body)
        intent.putExtra(Intent.EXTRA_TEXT, link)
        startActivity(Intent.createChooser(intent, getString(R.string.dialogfragment_comparteix)))
    }


    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        // Change Image Peview to Choosed Image
        if (requestCode == GALLERY_PICKUP_CODE && resultCode == Activity.RESULT_OK && data!!.data != null){
            val imageUri = data.data

            if (imageUri != null) {
                this.viewModel.uploadImageToFirebase( imageUri, this.currentUserUid )
                this.dismiss()
            }

        }
    }

    /*------------- CHANGE PROFILE IMAGE ---------------*/

    private fun changeProfileImage(){
        // Open Activity for pick image from GALLERY
        pickImage()
    }

    private fun pickImage(){
        val intent = Intent()
        intent.type = "image/*"
        intent.action = Intent.ACTION_GET_CONTENT
        startActivityForResult(intent, GALLERY_PICKUP_CODE)
    }




}