package net.codefastly.justshare.Common.Controllers

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import net.codefastly.justshare.Models.FirebasePublication
import net.codefastly.justshare.NetworkData.Repository

class TrendsFragmentVM: ViewModel() {

    private val repo = Repository()

    fun fetchPublicationData(): LiveData<MutableList<FirebasePublication>> {

        val mutableData = MutableLiveData<MutableList<FirebasePublication>>()
        repo.getPublicationData().observeForever { publicationList ->
            mutableData.value = publicationList
        }

        return mutableData
    }
}