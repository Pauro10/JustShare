package net.codefastly.justshare.Common.DashboardViews.Details

import android.content.Context
import android.content.Intent
import android.graphics.Paint
import android.net.Uri
import android.os.Bundle
import android.view.KeyEvent
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.Navigation
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import net.codefastly.justshare.Common.Controllers.PublicationDetailsFragmentVM
import net.codefastly.justshare.Common.DashboardActivity
import net.codefastly.justshare.HelperClasses.FirebaseCommentsAdapter
import net.codefastly.justshare.Models.FirebaseComment
import net.codefastly.justshare.Models.FirebasePublication
import net.codefastly.justshare.Models.FirebaseUser
import net.codefastly.justshare.NavGraphDirections
import net.codefastly.justshare.R
import net.codefastly.justshare.Utils.snack
import net.codefastly.justshare.databinding.FragmentPublicationDetailsBinding
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.squareup.picasso.Picasso
import kotlinx.android.synthetic.main.fragment_publication_details.*
import net.codefastly.justshare.Utils._chooseIconWithLink
import net.codefastly.justshare.Utils._splitLinks
import net.codefastly.justshare.Utils._verfifiedLinks


class PublicationDetailsFragment : Fragment() {

    private lateinit var binding: FragmentPublicationDetailsBinding
    private lateinit var currentUserUid : String

    // Inicializamos viewModel cuando lo necesitamos
    private val viewModel by lazy { ViewModelProvider(this).get(PublicationDetailsFragmentVM::class.java) }

    // RecyclerView Adapter
    private lateinit var adapter: FirebaseCommentsAdapter

    // FirebaseReference
    private lateinit var ref: DatabaseReference

    // Publicación a mostrar
    private var publication: FirebasePublication? = null
    private var user: FirebaseUser? = null

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment

        this.binding = DataBindingUtil.inflate( inflater, R.layout.fragment_publication_details,container,false )

        // Accedemos al activity para ocultar el menu
        (activity as DashboardActivity).setBottomMenuNavigation(false)

        // Recogemos userUID
        this.currentUserUid = requireActivity().getSharedPreferences(getString(R.string.prefs_file), Context.MODE_PRIVATE).getString("currentUid", "").toString()

        // Inicializamos RecyclerView
        this.initCommentsRecycler()

        // LISTENERS

        this.binding.btnBack.setOnClickListener {
            getFragmentManager()?.popBackStack()
            (activity as DashboardActivity).setBottomMenuNavigation(true)
            //val action = NavGraphDirections.actionToHomeFragment()
            //Navigation.findNavController(it).navigate(action)
        }

        this.binding.tfComment.setOnKeyListener { _, keyCode, event ->
            if( event.action == KeyEvent.ACTION_DOWN && keyCode == KeyEvent.KEYCODE_ENTER ){
                val message = this.binding.tfComment.text.toString()
                this.sendPublicationComment(message)
            }
            return@setOnKeyListener true
        }

        return this.binding.root
    }


    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)

        arguments.let { bundle ->

            this.publication = PublicationDetailsFragmentArgs.fromBundle(bundle!!).publication
            cargaDetalles()

            // Recogemos todos los comentarios
            this.observeData()


            // LISTENERS
                // AL hacer click en publicación
                this.binding.imgPublication.setOnClickListener { view ->
                    if( _verfifiedLinks( this.publication?.url!! ) ){
                        this.goToUrl( this.publication?.url!! )
                    }else{
                        //view.snack( this.publication?.url!! )
                        MaterialAlertDialogBuilder( requireContext() )
                            .setTitle(getString(R.string.imgPublication_title))
                            .setMessage(  _splitLinks(this.publication?.url!!)  )
                            .setNegativeButton(getString(R.string.imgPublication_no)) { dialog, which ->
                                // Respond to negative button press
                            }
                            .setPositiveButton(getString(R.string.imgPublication_si)) { dialog, which ->
                                this.goToUrl( this.publication?.url!! )
                            }
                            .show()
                    }
                }

                // AL hacer click en userLogo
                this.binding.imgOwner.setOnClickListener { view ->


                    // Redirigimos al fragmentDetails
                    val action = NavGraphDirections.actionGlobalOtherUserFragment()
                    action.publication = this.publication!!
                    Navigation.findNavController(view).navigate(action)
                }
                // Al hacer click sobre leerDescripcion
                this.binding.tvReadDescription.setOnClickListener {
                    if( this.binding.tvReadDescription.paintFlags == 0){
                        this.binding.tvReadDescription.paintFlags = Paint.UNDERLINE_TEXT_FLAG
                        this.binding.tvReadDescription.text = getString(R.string.publication_details_description)
                    }else{
                        this.binding.tvReadDescription.paintFlags = 0
                        this.binding.tvReadDescription.text = this.publication?.description
                    }

                }

            val singleItems = arrayOf(resources.getString(R.string.report_spam), resources.getString(R.string.report_inapropiat),
                resources.getString(R.string.report_violencia), resources.getString(R.string.report_altres))
            val checkedItem = 1

            this.binding.btnSocialReport.setOnClickListener {
                MaterialAlertDialogBuilder(requireContext())
                    .setTitle(resources.getString(R.string.report_title))
                    .setNeutralButton(resources.getString(R.string.report_cancel)) { dialog, which ->
                        // Respond to neutral button press
                    }
                    .setPositiveButton(resources.getString(R.string.report_enviar)) { dialog, which ->
                        view?.snack(getString(R.string.report_resultat))
                    }
                    // Single-choice items (initialized with checked item)
                    .setSingleChoiceItems(singleItems, checkedItem) { dialog, which ->
                        // Respond to item chosen
                    }
                    .show()
            }
        }


    }

    private fun cargaDetalles(){
        Picasso.get().load("https://firebasestorage.googleapis.com/v0/b/justshare-fb.appspot.com/o/profile_photo.jpg?alt=media&token=4e54c47b-1448-447d-b12b-ac25f70e7ae4").into(this.binding.imgOwner)

        if( this.publication?.imageUrl!!.isEmpty() ){
            Picasso.get().load( requireContext().getString( R.string.publication_image_link ) ).into(this.binding.imgPublication)
        }else{
            Picasso.get().load(this.publication?.imageUrl).into(this.binding.imgPublication)
        }

        // Change LinkIcon
        this.binding.imgLinkType.setBackgroundResource( _chooseIconWithLink( ( this.publication?.url!!) ) )

        this.binding.tvClicks.text = this.publication?.click.toString()
        this.binding.tvCategory.text = this.publication?.categories.toString()
        this.binding.tvReadDescription.paintFlags = Paint.UNDERLINE_TEXT_FLAG


    }

    private fun sendPublicationComment( message: String ){

        this.ref = FirebaseDatabase.getInstance().getReference("COMMENT")
        val newComment = FirebaseComment(user_id = this.currentUserUid, publication_id = this.publication?.id!! , text = message)
        val id = this.ref.push().key
        this.ref.child(id!!).setValue(newComment)

        this.binding.tfComment.text.clear()

        requireView().snack(getString(R.string.publication_details_success))

    }

    // Initialize first RecyclerView
    private fun initCommentsRecycler(){
        this.binding.rvComments.layoutManager = LinearLayoutManager( requireContext(), LinearLayoutManager.VERTICAL, false )
        this.adapter = FirebaseCommentsAdapter( requireContext() )
        this.binding.rvComments.adapter = this.adapter
    }

    // Observamos LIVE DATA de los comentarios
    private fun observeData(){
        this.binding.shimmerViewRvComments.startShimmer()


            this.viewModel.fetchUsernamePublication(this.publication?.owner.toString()).observe(viewLifecycleOwner, Observer { user ->
                this.binding.tvPublicationUser.text = user.username
                if( user.profileImage.isEmpty() ){
                    Picasso.get().load( requireContext().getString( R.string.profile_image_link ) ).into( this.binding.imgOwner )
                }else{
                    Picasso.get().load( user.profileImage ).into( this.binding.imgOwner )
                }

                this.viewModel.fetchPublicationComments( this.publication?.id!! ).observe( viewLifecycleOwner, Observer { commentsMutableList ->
                    this.binding.shimmerViewRvComments.stopShimmer()
                    this.binding.shimmerViewRvComments.visibility = View.GONE


                    this.adapter.setListData( commentsMutableList )
                    this.adapter.notifyDataSetChanged()
                })
            })
    }

    /* Redirección */

    private fun goToUrl( link: String ){
        val uri = Uri.parse( link )
        startActivity( Intent( Intent.ACTION_VIEW, uri ) )
    }

    

}