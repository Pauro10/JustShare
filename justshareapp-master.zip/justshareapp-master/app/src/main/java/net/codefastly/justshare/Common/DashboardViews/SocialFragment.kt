package net.codefastly.justshare.Common.DashboardViews

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.StaggeredGridLayoutManager
import net.codefastly.justshare.Common.Controllers.SocialFragmentVM
import net.codefastly.justshare.HelperClasses.FirebaseSocialAdapter
import net.codefastly.justshare.R
import net.codefastly.justshare.databinding.FragmentSocialBinding

class SocialFragment : Fragment() {


    // Inicializamos viewModel cuando lo necesitamos
    private val viewModel by lazy { ViewModelProvider(this).get(SocialFragmentVM::class.java) }

    private lateinit var socialAdapter: FirebaseSocialAdapter

    private lateinit var binding: FragmentSocialBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        this.binding = DataBindingUtil.inflate(inflater, R.layout.fragment_social, container, false)

        // Initialize Trends RecyclerView
        this.initSocialRecycler()



        return this.binding.root
    }


    private fun initSocialRecycler(){
        this.binding.rvSocial.layoutManager = LinearLayoutManager(requireContext())
        this.socialAdapter = FirebaseSocialAdapter( requireContext() )
        this.binding.rvSocial.adapter = this.socialAdapter

        this.observeSocialPublicationsData()
    }

    private fun observeSocialPublicationsData(){
        this.binding.shimmerViewRvSocial.startShimmer()
        this.viewModel.fetchSocialPublicationsData().observe( viewLifecycleOwner, Observer { socialPublication ->
            this.binding.shimmerViewRvSocial.stopShimmer()
            this.binding.shimmerViewRvSocial.visibility = View.GONE
            this.socialAdapter.setListData(socialPublication)
            this.socialAdapter.notifyDataSetChanged()
        })
    }




}