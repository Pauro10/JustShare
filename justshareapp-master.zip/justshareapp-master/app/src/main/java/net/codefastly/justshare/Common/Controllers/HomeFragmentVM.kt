package net.codefastly.justshare.Common.Controllers

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import net.codefastly.justshare.Models.FirebasePublication
import net.codefastly.justshare.Models.FollowingItem
import net.codefastly.justshare.Models.User
import net.codefastly.justshare.NetworkData.Repository


class HomeFragmentVM : ViewModel() {

    private val repo = Repository()


    fun fetchUserData(): LiveData<MutableList<User>>{
        // Cuandoi este mutable live data trenga información el metodo fetch ko retornará
        val mutableData = MutableLiveData<MutableList<User>>()
            // Va a estar escuchando hasta que se entren datos
            repo.getUserData().observeForever { userList ->
                mutableData.value = userList
            }

        return mutableData
    }

    fun fetchPublicationData(): LiveData<MutableList<FirebasePublication>>{

        val mutableData = MutableLiveData<MutableList<FirebasePublication>>()
        repo.getPublicationData().observeForever { publicationList ->
            mutableData.value = publicationList
        }

        return mutableData
    }


    /* PRUEBA 888992992... OJALÁ FUNCIONE */
    fun fetchFollowingItems(): LiveData<MutableList<FollowingItem>>{

        val mutableData = MutableLiveData<MutableList<FollowingItem>>()
            repo.getMapUsers().observeForever { mutableMapUsers ->
                repo.getFollowingItemsByUsers( mutableMapUsers ).observeForever { listFollowingItems ->
                    mutableData.value = listFollowingItems
                }
            }


        return mutableData
    }

}