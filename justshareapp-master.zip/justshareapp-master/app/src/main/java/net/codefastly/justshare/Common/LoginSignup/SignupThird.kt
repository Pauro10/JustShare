package net.codefastly.justshare.Common.LoginSignup

import android.content.Intent
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import androidx.annotation.RequiresApi
import androidx.databinding.DataBindingUtil
import net.codefastly.justshare.Models.User
import net.codefastly.justshare.R
import net.codefastly.justshare.Utils.snack
import net.codefastly.justshare.databinding.ActivitySignupThirdBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase

class SignupThird : AppCompatActivity() {

    private lateinit var binding: ActivitySignupThirdBinding
    private lateinit var auth: FirebaseAuth

    private var showSnack: Boolean = false
    // Firebase
    private lateinit var database: FirebaseDatabase
    private lateinit var reference: DatabaseReference

    // User variables
    private lateinit var tBirthday: String
    private lateinit var tGender: String
    private lateinit var tFullName: String
    private lateinit var tUserName: String
    private lateinit var tEmail: String
    private lateinit var tPassword: String
    private lateinit var tUid: String
    private lateinit var tCountryCode: String
    private lateinit var tPhoneNumber: String

    @RequiresApi(Build.VERSION_CODES.O)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        this.binding = DataBindingUtil.setContentView(this, R.layout.activity_signup_third)
        fullScreenMode()

        // Initialize Firebase Auth
        this.auth = FirebaseAuth.getInstance()

        // Instanciate database
        database = FirebaseDatabase.getInstance()
        // Reference working document
        reference = database.getReference("USER")

        // USER DATA
        this.tFullName  = intent.getStringExtra("EXTRA_SESSION_FULLNAME").toString()
        this.tUserName  = intent.getStringExtra("EXTRA_SESSION_USERNAME").toString()
        this.tEmail     = intent.getStringExtra("EXTRA_SESSION_EMAIL").toString()
        this.tPassword  = intent.getStringExtra("EXTRA_SESSION_PASSWORD").toString()
        this.tGender  = intent.getStringExtra("EXTRA_SESSION_GENDER").toString()
        this.tBirthday  = intent.getStringExtra("EXTRA_SESSION_BIRTHDAY").toString()

        // LISTENERS

        // Back Screen
        this.binding.btnSignUpBack.setOnClickListener {
            changeScreen(it, 0)
        }

        // Login Screen
        this.binding.btnLogin.setOnClickListener {
            changeScreen(it, 1)
        }

        // Validate Signup
        this.binding.btnSignupFinish.setOnClickListener {
            if (validateFields(it)){
                signUp(it, this.tEmail, this.tPassword)
            }
            else{
                return@setOnClickListener
            }
        }




    }

    private fun changeScreen(view: View, option: Int ){
        var intent = Intent()

        when(option){
            0 -> {
                // Back Screen
                intent = Intent(applicationContext, SignupSecond::class.java)
            }
            1 -> {
                // Login Screen
                intent = Intent(applicationContext, Login::class.java).apply { putExtra("EXTRA_SHOW_SNACK",showSnack) }
            }
        }

        startActivity(intent)
        if(option == 0){
            overridePendingTransition(R.anim.slide_in_left, R.anim.slide_out_right)
        }else{
            overridePendingTransition(R.anim.slide_in_right, R.anim.slide_out_left)
        }
        finish()
    }

    private fun validateFields(view: View): Boolean {
        return if (this.binding.tfTel.text.toString() == "" || this.binding.tfTel.text.toString().length != 9){
            view.snack(getString(R.string.signup_phone))
            false
        } else {
            true
        }
    }

    @RequiresApi(Build.VERSION_CODES.O)
    private fun signUp(view: View, email: String, pass: String){
        this.auth.createUserWithEmailAndPassword(email, pass)
            .addOnCompleteListener(this) { task ->
                if( task.isSuccessful ){
                    val user: FirebaseUser? = task.getResult()!!.user
                    referenceUserDatabase(view, user)
                    // Change to Login screen
                    showSnack = true
                        changeScreen(view, 1)
                }else{
                    view.snack(getString(R.string.signup_error))
                }
            }
    }

    @RequiresApi(Build.VERSION_CODES.O)
    private fun referenceUserDatabase(view: View, user: FirebaseUser?){
        //Collect user data
        this.tPhoneNumber = this.binding.tfTel.text.toString().trim()
        this.tCountryCode = this.binding.cpCountry.selectedCountryCode

        if (user != null){
            this.tUid = user.uid
        } else {
            return
        }
        val userModel = User(fullName = this.tFullName, username = this.tUserName,
                             password = this.tPassword, gender = this.tGender,
                             birthday = this.tBirthday, phoneNumber = this.tPhoneNumber,
                             countryCode = this.tCountryCode, profileImage = "https://firebasestorage.googleapis.com/v0/b/justshare-fb.appspot.com/o/profile_photo.jpg?alt=media&token=4e54c47b-1448-447d-b12b-ac25f70e7ae4")

        //val id = this.reference.push().key

        // Send data to Firebase
        this.reference.child(tUid).setValue(userModel)
    }

    private fun  fullScreenMode(){
        // Hide actionBar and fullScreen mode
        supportActionBar?.hide()
        window.setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN)
    }

}