package net.codefastly.justshare.HelperClasses

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.navigation.NavGraph
import androidx.navigation.Navigation
import androidx.recyclerview.widget.RecyclerView
import net.codefastly.justshare.Models.FollowingItem
import net.codefastly.justshare.R
import net.codefastly.justshare.Utils.snack
import com.squareup.picasso.Picasso
import net.codefastly.justshare.NavGraphDirections

/**
 * CREATED BY JoseUgal
 */
class FirebaseFollowingAdapter( private val context: Context ): RecyclerView.Adapter<FirebaseFollowingAdapter.FirebaseFollowingViewHolder>() {

    private var dataList = mutableListOf<FollowingItem>()

    fun setListData( data: MutableList<FollowingItem> ){
        dataList = data
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FirebaseFollowingViewHolder {
        val view = LayoutInflater.from( context ).inflate(R.layout.rv_item_following, parent, false)
        return FirebaseFollowingViewHolder(view)
    }

    override fun onBindViewHolder(holder: FirebaseFollowingViewHolder, position: Int) {
        val followingItem = dataList[position]
        holder.render(followingItem)
    }

    override fun getItemCount(): Int {
        return if(dataList.size > 0){
            dataList.size
        }else{
            0
        }
    }

    inner class FirebaseFollowingViewHolder( itemView: View ):RecyclerView.ViewHolder( itemView ){
        fun render( followingItem: FollowingItem ) {

            if( followingItem.user.profileImage.isEmpty() ){
                Picasso.get().load( context.getString( R.string.profile_image_link ) ).placeholder(R.drawable.ic_launcher_background).into( itemView.findViewById<ImageView>(R.id.imgFirstPublication) )
            }else{
                Picasso.get().load(followingItem.user.profileImage).placeholder(R.drawable.ic_launcher_background).into( itemView.findViewById<ImageView>(R.id.imgFirstPublication) )
            }

            if( followingItem.publication.imageUrl.isEmpty() ){
                Picasso.get().load( context.getString( R.string.publication_image_link ) ).placeholder(R.drawable.ic_launcher_background).into( itemView.findViewById<ImageView>(R.id.imgSecondPublication) )
            }else{
                Picasso.get().load(followingItem.publication.imageUrl).placeholder(R.drawable.ic_launcher_background).into( itemView.findViewById<ImageView>(R.id.imgSecondPublication) )
            }



            itemView.findViewById<TextView>(R.id.tvUsername).text = followingItem.user.username
            itemView.findViewById<ImageView>(R.id.imgFirstPublication).setOnClickListener {
                // it.snack( followingItem.profileImage )
                val action = NavGraphDirections.actionGlobalOtherUserFragment()
                action.publication = followingItem.publication
                Navigation.findNavController( it ).navigate( action )
            }

            itemView.findViewById<ImageView>(R.id.imgSecondPublication).setOnClickListener {
                // it.snack( followingItem.publication.imageUrl + " --> " + followingItem.publication.url )
                val action = NavGraphDirections.actionToPublicationDetails()
                action.publication = followingItem.publication
                Navigation.findNavController( it ).navigate( action )
            }

        }
    }

}