package net.codefastly.justshare.Common.DashboardViews

import android.content.Context
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.Navigation
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.StaggeredGridLayoutManager
import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.squareup.picasso.Picasso
import net.codefastly.justshare.Common.Controllers.ProfileFragmentVM
import net.codefastly.justshare.Common.DashboardActivity
import net.codefastly.justshare.Common.DashboardViews.Details.PublicationDetailsFragmentArgs
import net.codefastly.justshare.HelperClasses.FirebaseCommentsAdapter
import net.codefastly.justshare.HelperClasses.FirebaseOtherUserAdapter
import net.codefastly.justshare.HelperClasses.FirebaseUserAdapter
import net.codefastly.justshare.Models.FirebasePublication
import net.codefastly.justshare.NavGraphDirections
import net.codefastly.justshare.R
import net.codefastly.justshare.databinding.FragmentOthersProfileBinding

class OtherUserFragment : Fragment() {

    private lateinit var binding: FragmentOthersProfileBinding
    private lateinit var currentUserUid : String
    var usersReference: DatabaseReference? = null


    // Inicializamos viewModel cuando lo necesitamos
    private val viewModel by lazy { ViewModelProvider(this).get(ProfileFragmentVM::class.java) }

    private lateinit var userAdapter: FirebaseOtherUserAdapter

    private var publication: FirebasePublication? = null

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        this.binding = DataBindingUtil.inflate(inflater, R.layout.fragment_others_profile, container, false)

        usersReference = FirebaseDatabase.getInstance().getReference("USER")

        // Recogemos userUID
        this.currentUserUid = requireActivity().getSharedPreferences(getString(R.string.prefs_file), Context.MODE_PRIVATE).getString("currentUid", "").toString()

        // Inicializamos RecyclerView
        this.initProfileRecycler()

        this.binding.btnBack.setOnClickListener { view ->
            getFragmentManager()?.popBackStack()
            // Redirigimos al fragmentDetails
            //val action = NavGraphDirections.actionToHomeFragment()
            //action.publication = this.publication!!
            //Navigation.findNavController(view).navigate(action)
        }

        return this.binding.root
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        arguments.let { bundle ->
            this.publication = PublicationDetailsFragmentArgs.fromBundle(bundle!!).publication
            this.observepublicationProfileData()
        }
    }


    private fun initProfileRecycler(){
        this.binding.rvUser.layoutManager = StaggeredGridLayoutManager(2, StaggeredGridLayoutManager.VERTICAL)
        this.userAdapter = FirebaseOtherUserAdapter( requireContext() )
        this.binding.rvUser.adapter = this.userAdapter
    }

    private fun observepublicationProfileData(){
        this.viewModel.fetchUserData(this.publication?.owner.toString()).observe(viewLifecycleOwner, Observer { usuario ->
            this.binding.tvNickname.text = usuario.username

            this.viewModel.fetchPublicationProfileData(this.publication?.owner.toString()).observe( viewLifecycleOwner, Observer { observePublicacions ->
                this.userAdapter.setListData( observePublicacions )
                this.userAdapter.notifyDataSetChanged()})
            if(usuario.profileImage.isEmpty()){
                Picasso.get().load(requireContext().getString(R.string.profile_image_link)).into(this.binding.ivUser)
            }else{
                Picasso.get().load(usuario.profileImage).into(this.binding.ivUser)
            }
        })
    }

}