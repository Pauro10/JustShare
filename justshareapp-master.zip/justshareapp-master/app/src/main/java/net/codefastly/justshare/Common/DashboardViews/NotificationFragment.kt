package net.codefastly.justshare.Common.DashboardViews

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.databinding.DataBindingUtil
import net.codefastly.justshare.R
import net.codefastly.justshare.databinding.FragmentNotificationBinding

class NotificationFragment : Fragment() {

    private lateinit var binding : FragmentNotificationBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        this.binding = DataBindingUtil.inflate(inflater, R.layout.fragment_notification, container, false)



        return this.binding.root
    }


}