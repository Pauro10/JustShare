package net.codefastly.justshare.Models

import android.os.Build
import androidx.annotation.RequiresApi
import java.time.LocalDateTime


data class User @RequiresApi(Build.VERSION_CODES.O) constructor(
   val fullName: String,
   val username: String,
   val password: String,
   val gender: String,
   val birthday: String,
   val phoneNumber: String,
   val countryCode: String,
   val profileImage: String,
   val registrationDate: LocalDateTime = LocalDateTime.now()
) {



  }