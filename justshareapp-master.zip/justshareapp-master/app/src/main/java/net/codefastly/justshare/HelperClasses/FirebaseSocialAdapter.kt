package net.codefastly.justshare.HelperClasses

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.navigation.Navigation
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import net.codefastly.justshare.R
import com.squareup.picasso.Picasso
import net.codefastly.justshare.Models.SocialPublication
import net.codefastly.justshare.NavGraphDirections
import net.codefastly.justshare.Utils._chooseIconWithLink
import net.codefastly.justshare.Utils.snack

class FirebaseSocialAdapter(private val context: Context): RecyclerView.Adapter<FirebaseSocialAdapter.FirebaseSocialViewHolder>() {

    private var dataList = mutableListOf<SocialPublication>()

    val singleItems = arrayOf(context.getString(R.string.report_spam), context.getString(R.string.report_inapropiat),
        context.getString(R.string.report_violencia), context.getString(R.string.report_altres))
    val checkedItem = 0

    fun setListData(data: MutableList<SocialPublication>){
        dataList = data
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FirebaseSocialViewHolder {
        val view = LayoutInflater.from(context).inflate(R.layout.rv_item_social, parent, false)
        return FirebaseSocialViewHolder(view)
    }

    override fun onBindViewHolder(holder: FirebaseSocialViewHolder, position: Int) {
        val publication = dataList[position]
        holder.render(publication)

    }

    override fun getItemCount(): Int {
        return if (dataList.size > 0){
            dataList.size
        } else {
            0
        }
    }

    inner class FirebaseSocialViewHolder(itemView:View): RecyclerView.ViewHolder(itemView){

        fun render(social: SocialPublication){

            // Cargamos img publicación
            if( social.publication.imageUrl.isEmpty() ){
                Picasso.get().load( context.getString( R.string.publication_image_link ) ).placeholder(R.drawable.ic_launcher_background).into(itemView.findViewById<ImageView>(R.id.imgSocial))
            }else {
                Picasso.get().load(social.publication.imageUrl).placeholder(R.drawable.ic_launcher_background).into(itemView.findViewById<ImageView>(R.id.imgSocial))
            }
            // Cargamos img user

            if( social.user.profileImage.isEmpty() ){
                Picasso.get().load( context.getString( R.string.profile_image_link ) ).placeholder(R.drawable.ic_launcher_background).into( itemView.findViewById<ImageView>(R.id.imgSocialOwner))
            }else {
                Picasso.get().load( social.user.profileImage ).placeholder(R.drawable.ic_launcher_background).into( itemView.findViewById<ImageView>(R.id.imgSocialOwner) )
            }

            // Change LinkIcon
            itemView.findViewById<ImageView>(R.id.imgLinkType).setBackgroundResource( _chooseIconWithLink( ( social.publication.url ) ) )


            // Publication CLics
            itemView.findViewById<TextView>(R.id.tvSocialClicks).text = social.publication.click.toString()
            // Publication username
            itemView.findViewById<TextView>(R.id.tvSocialOwner).text = social.user.username
            // Publication Report Button
            itemView.findViewById<Button>(R.id.btnSocialReport).setOnClickListener {
                MaterialAlertDialogBuilder(context)
                    .setTitle(context.getString(R.string.report_title))
                    .setNeutralButton(context.getString(R.string.report_cancel)) { dialog, which ->
                        // Respond to neutral button press
                    }
                    .setPositiveButton(context.getString(R.string.report_enviar)) { dialog, which ->
                        it.snack(context.getString(R.string.report_resultat))
                    }
                    // Single-choice items (initialized with checked item)
                    .setSingleChoiceItems(singleItems, checkedItem) { dialog, which ->
                        // Respond to item chosen
                    }
                    .show()
            }
            // Redirigimos a los datos de la publicacion
            itemView.findViewById<ImageView>(R.id.imgSocial).setOnClickListener {

                // Redirigimos al fragmentDetails
                val action = NavGraphDirections.actionToPublicationDetails()
                action.publication = social.publication
                Navigation.findNavController(it).navigate(action)
            }

            itemView.findViewById<ImageView>(R.id.imgSocialOwner).setOnClickListener { view ->

                // Redirigimos al fragmentDetails
                val action = NavGraphDirections.actionGlobalOtherUserFragment()
                action.publication = social.publication!!
                Navigation.findNavController(view).navigate(action)
            }

        }
    }

}