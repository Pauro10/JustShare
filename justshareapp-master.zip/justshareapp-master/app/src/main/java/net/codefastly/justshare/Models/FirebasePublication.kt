package net.codefastly.justshare.Models

import java.io.Serializable
import java.time.LocalDateTime

class FirebasePublication
    (
     val id: String,
     val categories: String,
     val click: Int,
     val creationDate: LocalDateTime,
     val description: String,
     val imageUrl: String,
     val owner: String,
     val url: String
    ): Serializable
    {
    }